#pragma once

#include "EZ-Template/api.hpp"
#include "api.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>

extern Drive chassis;

// Your motors, sensors, etc. should go here.  Below are examples

inline pros::Motor cM(15);
inline pros::Motor FiM(-14);
inline pros::Motor lb(16);
inline pros::MotorGroup img ({15, -14});
inline pros::adi::DigitalOut mogo('-A');
inline pros::adi::DigitalOut sweeper('B');

inline pros::Optical mogo_opt(6);

inline pros::Motor lm1(-1);
inline pros::Motor lm2(-2);
inline pros::Motor lm3(3);
inline pros::MotorGroup lmg({-1, -2, 3});

inline pros::Motor rm1(11);
inline pros::Motor rm2(12);
inline pros::Motor rm3(-13);
inline pros::MotorGroup rmg({11, 12, -13});

inline pros::Rotation lbrot(17);